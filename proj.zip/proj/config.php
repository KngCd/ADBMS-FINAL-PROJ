<?php
// 
$con = mysqli_connect("localhost","root","","proj") or die("Coudn't connect");

?>
